(function(value) {
	var v = (value === "ON") ? "1" : "0";
	return "{\"up2\":\""+ v + "\", \"down2\":\"0\"}";
})(input);