(function(value) {
	var v = (value === "ON") ? "1" : "0";
	return "{\"down2\":\""+ v + "\", \"up2\":\"0\"}";
})(input);