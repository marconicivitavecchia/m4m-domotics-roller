(function(value) {
	var v = (value === "ON") ? "1" : "0";
	return "{\"up1\":\""+ v + "\", \"down1\":\"0\"}";
})(input);