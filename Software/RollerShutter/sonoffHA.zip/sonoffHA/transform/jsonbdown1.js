(function(value) {
	var v = (value === "ON") ? "1" : "0";
	return "{\"down1\":\""+ v + "\", \"up1\":\"0\"}";
})(input);